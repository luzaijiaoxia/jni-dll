#include"test.h"
vector<vector<int>> test_func(vector<vector<int>> &variable1, vector<vector<int>> &variable2) {
	vector<vector<int>> sum(variable1.size());
	for (int i = 0; i < variable1.size(); i++) {
		for(int j=0;j<variable1[i].size();j++){
			sum[i].push_back(variable1[i][j] + variable2[i][j]);
		}
	}

	return sum;
}