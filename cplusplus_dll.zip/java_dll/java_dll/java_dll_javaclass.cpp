#include"java_dll_javaclass.h";
#include"test.h";
JNIEXPORT jobjectArray JNICALL Java_java_1dll_javaclass_sum_1func
(JNIEnv *env, jclass, jobjectArray var1_array, jobjectArray var2_array) {
	//input
	vector<vector<int>> var1;
	int num1 = env->GetArrayLength(var1_array);
	for (int i = 0; i < num1; i++) {
		vector<int> c;
		jintArray jc = jintArray(env->GetObjectArrayElement(var1_array, i));//ȡ��i��
		jint *jc_pointer = env->GetIntArrayElements(jc, NULL);
		jint jc_len = env->GetArrayLength(jc);
		for (int j = 0; j < jc_len; j++) {
			c.push_back(jc_pointer[j]);
		}
		var1.push_back(c);
	}

	vector<vector<int>> var2;
	int num2 = env->GetArrayLength(var1_array);
	for (int i = 0; i < num2; i++) {
		vector<int> c;
		jintArray jc = jintArray(env->GetObjectArrayElement(var2_array, i));//ȡ��i��
		jint *jc_pointer = env->GetIntArrayElements(jc, NULL);
		jint jc_len = env->GetArrayLength(jc);
		for (int j = 0; j < jc_len; j++) {
			c.push_back(jc_pointer[j]);
		}
		var2.push_back(c);
	}

	//output
	vector<vector<int>> sum = test_func(var1, var2);
	int X_len = sum.size();
	int Y_len = sum[0].size();
	jclass initClass = env->FindClass("[I");//�ҵ�һ��Int�࣬�����double����[D
	jobjectArray sum_return = env->NewObjectArray(X_len, initClass, NULL);
	for (int i = 0; i < X_len; i++) {
		jintArray output = env->NewIntArray(Y_len);//
		jint *destArrayElems = env->GetIntArrayElements(output, NULL);
		for (int j = 0; j < Y_len; j++) {
			destArrayElems[j] = sum[i][j];
		}
		env->SetIntArrayRegion(output, 0, Y_len, destArrayElems);
		env->SetObjectArrayElement(sum_return, i, output);
	}

	return sum_return;
}