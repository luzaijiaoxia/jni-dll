#include "test.h";
#include <iostream>
using namespace std;
int main() {
	vector<vector<int>> variable1 = { { 1,2,3 },{2,3,4} };
	vector<vector<int>> variable2 = { { 4,5,6 } ,{5,6,7} };
	vector<vector<int>> sum = test_func(variable1,variable2);

	cout << "��ͽ����" << endl;
	for (int i = 0; i < sum.size(); i++) {
		for (int j = 0; j < sum[i].size(); j++) {
			std::cout << sum[i][j] << ' ';
		}
		std::cout << std::endl;
	}
	return 0;
}