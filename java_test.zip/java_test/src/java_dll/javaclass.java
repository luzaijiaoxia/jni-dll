package java_dll;

public class javaclass {
	static {
		System.loadLibrary("java_dll");
	}
	public static native int[][] sum_func(int[][] var1,int[][] var2);
	public static void main(String[] args) {
		
		int[][] var1 = { { 1,2,3 },{2,3,4} };
		int[][] var2 = { { 4,5,6 } ,{5,6,7} };
		
		System.out.println("input 1:");		
		for (int i = 0; i < var1.length; i++) {
			for(int j=0;j<var1[i].length;j++) {
			   System.out.print(var1[i][j] + ", ");  
			}
			System.out.println();
		}
		System.out.println();
		
		System.out.println("input 2:");		
		for (int i = 0; i < var2.length; i++) {
			for(int j=0;j<var2[i].length;j++) {
			   System.out.print(var2[i][j] + ", ");  
			}
			System.out.println();
		}
		System.out.println();
				
		
		int[][] sum;
		sum= sum_func(var1,var2);
		System.out.println("output:");
		for (int i = 0; i < sum.length; i++) {
			for(int j=0;j<sum[i].length;j++) {
			   System.out.print(sum[i][j] + ", ");  
			}
			System.out.println();
		}
		System.out.println();	
		
	}
}
