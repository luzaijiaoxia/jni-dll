package java_dll;

public class javaclass {
	static {
		System.loadLibrary("java_dll");
	}
	public static native int[] sum_func(int[] var1,int[] var2);
	public static void main(String[] args) {
		int[] var1 = {1,2,3};
		int[] var2 = {5,6,7};
		
		System.out.println("input 1:");		
		for (int i = 0; i < var1.length; i++) {		
			   System.out.print(var1[i] + ", ");  
		}
		System.out.println();
		
		System.out.println("input 2:");
		for (int i = 0; i < var2.length; i++) {		
			   System.out.print(var2[i] + ", ");  
		}
		System.out.println();
				
		System.out.println("output:");
		int[] sum;
		sum= sum_func(var1,var2);
		for (int i = 0; i < sum.length; i++) {		
			   System.out.print(sum[i] + ", ");  
		}  
		System.out.println();		
	}
}
